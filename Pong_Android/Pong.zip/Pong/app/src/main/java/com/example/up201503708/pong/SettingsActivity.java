package com.example.up201503708.pong;

import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends AppCompatActivity {

    private Intent intent;
    private SeekBar ballVelocityBar;
    private SeekBar paddleVelocityBar;
    private SeekBar aiPaddleVelocityBar;
    private Spinner maps;
    private FileInputStream fileInputStream;
    private InputStream inputStream;
    private boolean useDefaultFile;
    private static final double paddle_min=0.00556;
    private static final double paddle_max=0.034722;
    private static final double ai_paddle_min=0.00556;
    private static final double ai_paddle_max=0.017361;
    private static final double ball_min=0.005859;
    private static final double ball_max=0.0175781;

    /**
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_settings);

        Button back=(Button)findViewById(R.id.back);
        Button save=(Button)findViewById(R.id.save);
        Button restore=(Button)findViewById(R.id.d);
        ballVelocityBar=(SeekBar)findViewById(R.id.ballVelocity);
        paddleVelocityBar=(SeekBar)findViewById(R.id.paddleVelocity);
        aiPaddleVelocityBar=(SeekBar)findViewById(R.id.aiPaddleVelocity);
        maps=(Spinner)findViewById(R.id.spinner);

        intent=new Intent(this,MainActivity.class);

        readSettings();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        });

        restore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setDefautSettings();
            }
        });
    }

    /**
     * adds items to the spinner and updates the currently selected item
     *
     * @param selectedMap name of the selected map
     */
    private void addItemsOnSpinner(String selectedMap){
        String mapNames[]=null;

        try {
            mapNames = getAssets().list("maps");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            if(mapNames!=null){
                List<String> list = new ArrayList<String>();
                int selection=-1;

                for(int i=0;i<mapNames.length;i++){
                    list.add(mapNames[i]);
                    if(mapNames[i].equals(selectedMap)){
                        selection=i;
                    }
                }

                ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
                dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                maps.setAdapter(dataAdapter);

                maps.setSelection(selection);
            }
        }
    }

    /**
     * saves the current state to a file
     */
    private void saveSettings(){
        String message;
        String mapName;
        double ballVelocity=ball_min+((ball_max-ball_min)*((double)(ballVelocityBar.getProgress())/100));
        double paddleVelocity=paddle_min+((paddle_max-paddle_min)*((double)(paddleVelocityBar.getProgress())/100));
        double aiPaddleVelocity=ai_paddle_min+((ai_paddle_max-ai_paddle_min)*((double)(aiPaddleVelocityBar.getProgress())/100));

        mapName=(String)maps.getSelectedItem();

        message=mapName+"/"+ballVelocity+"/"+paddleVelocity+"/"+aiPaddleVelocity+"/";


        updateSettings(message);
        readSettings();
    }

    /**
     * opens the settings file and calls the function that read it
     */

    private void readSettings(){
        boolean exists;
        File file= getFileStreamPath("settings");
        fileInputStream=null;
        inputStream=null;

        if(file==null || !file.exists()){
            exists=false;
        }
        else{
            exists=true;
        }


        if(exists){
            try {
                fileInputStream = openFileInput("settings");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
        else{
            try {
                inputStream =getAssets().open("settings.txt");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }

        if(fileInputStream==null && inputStream!=null){
            useDefaultFile=true;
        }
        else if(fileInputStream!=null && inputStream==null){
            useDefaultFile=false;
        }
        else{
            useDefaultFile=true;
        }

        readMapName();
        readVariables();
    }

    /**
     * reads the map name and call the function that adds the available maps to the spinner
     */
    private void readMapName(){
        String message="";
        boolean reading;
        int character;

        if(useDefaultFile){
            try {
                reading=true;
                while (reading) {
                    character = inputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }

        }
        else if(!useDefaultFile){
            try {
                reading=true;
                while (reading) {
                    character = fileInputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
       addItemsOnSpinner(message);
    }

    /**
     * reads the ballVelocity, paddleVelocity and computerPaddleVelocity and updates the seekbars
     */
    public void readVariables(){
        String message="";
        boolean reading;
        int character;
        double ballVelocity=0;
        double paddleVelocity=0;
        double computerPaddleVelocity=0;

        if(useDefaultFile){
            try {
                reading=true;
                while (reading) {
                    character = inputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }

                ballVelocity=Double.parseDouble(message);
                message="";

                reading=true;
                while (reading) {
                    character = inputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }

                paddleVelocity=Double.parseDouble(message);
                message="";

                reading=true;
                while (reading) {
                    character = inputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }

                computerPaddleVelocity=Double.parseDouble(message);

            }
            catch(Exception e){
                e.printStackTrace();
            }

        }
        else if(!useDefaultFile){
            try {
                reading=true;
                while (reading) {
                    character = fileInputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }

                ballVelocity=Double.parseDouble(message);
                message="";

                reading=true;
                while (reading) {
                    character = fileInputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }

                paddleVelocity=Double.parseDouble(message);
                message="";

                reading=true;
                while (reading) {
                    character = fileInputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }

                computerPaddleVelocity=Double.parseDouble(message);

            }
            catch(Exception e){
                e.printStackTrace();
            }
        }

        try {
            if (fileInputStream != null) {
                fileInputStream.close();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

        try {
            if (inputStream != null) {
                inputStream.close();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

        ballVelocityBar.setProgress((int)(((ballVelocity-ball_min)/(ball_max-ball_min))*100));
        paddleVelocityBar.setProgress((int)(((paddleVelocity-paddle_min)/(paddle_max-paddle_min))*100));
        aiPaddleVelocityBar.setProgress((int)(((computerPaddleVelocity-ai_paddle_min)/(ai_paddle_max-ai_paddle_min))*100));
    }


    /**
     * reads the default settings file and calls the function that updates the settings
     */
    private void setDefautSettings(){
    InputStream inputStream=null;
    int character;
    boolean reading;

    String message="";

        try {
            inputStream =getAssets().open("settings.txt");
            reading=true;

            while(reading){
                character=inputStream.read();
                if(character==-1){
                    reading=false;
                }
                else{
                    message=message+(char)character;
                }
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        finally{
            try {
                if (inputStream != null) {
                    inputStream.close();
                    updateSettings(message);
                    readSettings();
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    /**
     * updates settings file
     *
     * @param message String containing the settings information to be copied to the file
     */
    private void updateSettings(String message){
        FileOutputStream fileOutputStream=null;

        try {
            fileOutputStream = openFileOutput("settings", MODE_PRIVATE);
            fileOutputStream.write(message.getBytes());
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            try {
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }

    }

}
