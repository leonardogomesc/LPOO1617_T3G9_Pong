package com.example.up201503708.pong;

public class Ball {

	private double position[];  //current ball position
	private double vector[]; //current ball direction

	/**
	 *
	 * @param x  x coordinate of the ball
	 * @param y  y coordinate of the ball
	 * @param vx  x component of the current ball movement direction
	 * @param vy  y component of the current ball movement direction
	 */
	public Ball(double x,double y, double vx,double vy){
		position=new double[2];
		position[0]=x;
		position[1]=y;
		vector=new double[2];
		vector[0]=vx;
		vector[1]=vy;
      }


	/**
	 *
	 * @return position array containing the current x and y coordinate of the ball
	 */
	public double[] getPosition() {
		return position;
	}

	/**
	 *
	 * @param position sets the x coordinate
	 */
	public void setPositionx(double position) {
		this.position[0] = position;
	}

	/**
	 *
	 * @param position sets the y coordinate
	 */
	public void setPositiony(double position) {
		this.position[1] = position;
	}

	/**
	 *
	 * @return current ball direction
	 */
	public double[] getVector() {
		return vector;
	}

	/**
	 *
	 * @param vector sets the x component of the ball´s direction
	 */
	
	public void setVector_x(double vector) {
		this.vector[0] = vector;
	}

	/**
	 *
	 * @param vector sets the y component of the ball´s direction
	 */
	public void setVector_y(double vector) {
		this.vector[1] = vector;
	}


	/**
	 *
	 * @param vector sets the ball's direction
	 */
	public void setVector(double[] vector) {
		this.vector = vector;
	}
}
