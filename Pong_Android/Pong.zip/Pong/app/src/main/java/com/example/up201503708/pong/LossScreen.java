package com.example.up201503708.pong;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class LossScreen extends AppCompatActivity {

    private Intent menu;
    private Intent retry;

    /**
     * shows the score and has a retry button and a menu button
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_loss_screen);

        Button r=(Button)findViewById(R.id.r);
        Button m=(Button)findViewById(R.id.m);
        TextView scoreText= (TextView)findViewById(R.id.score);
        int score[]=(int[])getIntent().getExtras().get("Score");
        String scoreString=score[0]+"        -        "+score[1];

        scoreText.setText(scoreString.toCharArray(),0,scoreString.length());

        menu=new Intent(this, MainActivity.class);
        retry=new Intent(this, GameActivity.class);

        retry.putExtra("Number of Players",(int)getIntent().getExtras().get("Number of Players"));
        retry.putExtra("Score",score);

        m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(menu);
            }
        });

        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(retry);
            }
        });
    }
}
