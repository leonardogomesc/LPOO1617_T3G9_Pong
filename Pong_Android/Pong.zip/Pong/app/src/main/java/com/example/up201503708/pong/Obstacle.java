package com.example.up201503708.pong;

public class Obstacle {
private double k[];
private double b[];
private double pos[];
private double size[];

	/**
	 *
	 * @param x x coordinate relative to the center of the object
	 * @param y y coordinate relative to the center of the object
	 * @param size_x horizontal size in pixels
	 * @param size_y vertical size in pixels
	 */

public Obstacle(double x,double y,double size_x,double size_y){
	pos=new double[2];
	pos[0]=x;
	pos[1]=y;
	size=new double [2];
	size[0]=size_x;
	size[1]=size_y;
	k=new double [2];
	b=new double [2];
	calculator();
}

	/**
	 *
	 * @return position array
	 */
	public double[] getPos() {
	return pos;
}

	/**
	 *
	 * @return size array
	 */
	public double[] getSize() {
	return size;
}

	/**
	 *
	 * @return k
	 */
	public double[] getK() {
	return k;
}

	/**
	 *
	 * @return b
	 */
	public double[] getB() {
	return b;
}

	/**
	 * calculates the k and b for the equation of a line (y= k*x+b) that passes through the upper left corner
	 * and the lower right corner (corresponds to index 0 in the array) and the upper right corner
	 * and the lower left corner (corresponds to index 1 in the array).
	 *
	 * these values are used in the obstacle collision function in the game class
	 */
	private void calculator(){
	double x1,x2,x3,x4,y1,y2,y3,y4;
	
	x1=pos[0]-size[0]/2;
	y1=pos[1]-size[1]/2;
	
	x2=pos[0]+size[0]/2;
	y2=pos[1]-size[1]/2;
	
	x3=pos[0]-size[0]/2;
	y3=pos[1]+size[1]/2;
	
	x4=pos[0]+size[0]/2;
	y4=pos[1]+size[1]/2;
	
	k[0]=(y4-y1)/(x4-x1);
	k[1]=(y3-y2)/(x3-x2);
	
	b[0]=y1-k[0]*x1;
	b[1]=y2-k[1]*x2;
}
}
