package com.example.up201503708.pong;

public class Player {
private double pos[];

	/**
	 *
	 * @param x x coordinate relative to the center of the object
	 * @param y y coordinate relative to the center of the object
	 */
	public Player (double x, double y){
	pos=new double[2];
	pos[0]=x;
	pos[1]=y;
}

	/**
	 *
	 * @return position array
	 */
	public double[] getPos() {
	return pos;
}

	/**
	 *
	 * @param pos set x position
	 */
	public void setPos_x(double pos) {
	this.pos[0] = pos;
}

	/**
	 *
	 * @param pos set y position
	 */
	public void setPos_y(double pos) {
	this.pos[1] = pos;
}

}
