package com.example.up201503708.pong;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private Intent i;
    private Intent settings;

    /**
     * this is the main menu where you can start a game or go to the settings
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        Button p1=(Button)findViewById(R.id.p1);
        Button p2=(Button)findViewById(R.id.p2);
        Button s=(Button)findViewById(R.id.s);

        i= new Intent(this, GameActivity.class);
        settings=new Intent(this, SettingsActivity.class);

        i.putExtra("Score",new int[]{0,0});

        p1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i.putExtra("Number of Players",1);
                startActivity(i);
            }
        });

        p2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i.putExtra("Number of Players",2);
                startActivity(i);
            }
        });

        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(settings);
            }
        });
    }
}
