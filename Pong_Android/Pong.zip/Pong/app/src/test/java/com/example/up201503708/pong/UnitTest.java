package com.example.up201503708.pong;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class UnitTest {
    @Test
    public void checkBallMovement_x() throws Exception {
        Game game=new Game(0,0,100,100,10,new double[]{10,30},1,1,1,new Ball(50,50,1,0),null);
        game.setPlaying(true);

        assertEquals((int)50,(int)game.getBall().getPosition()[0]);
        assertEquals((int)50,(int)game.getBall().getPosition()[1]);

        game.update_unitTest();


        assertEquals((int)51,(int)game.getBall().getPosition()[0]);
        assertEquals((int)50,(int)game.getBall().getPosition()[1]);

    }

    @Test
    public void checkBallMovement_y() throws Exception {
        Game game=new Game(0,0,100,100,10,new double[]{10,30},1,1,1,new Ball(50,50,0,1),null);
        game.setPlaying(true);

        assertEquals((int)50,(int)game.getBall().getPosition()[0]);
        assertEquals((int)50,(int)game.getBall().getPosition()[1]);

        game.update_unitTest();

        assertEquals((int)50,(int)game.getBall().getPosition()[0]);
        assertEquals((int)51,(int)game.getBall().getPosition()[1]);
    }

    @Test
    public void checkCollisionWithObstacle() throws Exception {
        Game game=new Game(0,0,200,200,10,new double[]{10,30},1,1,1,new Ball(100,100,1,0),new Obstacle[]{new Obstacle(115,100,20,20)});
        game.setPlaying(true);

        assertEquals(1,(int)game.getBall().getVector()[0]);
        assertEquals(0,(int)game.getBall().getVector()[1]);

        game.update_unitTest();

        assertEquals(1,(int)game.getBall().getVector()[0]);
        assertEquals(0,(int)game.getBall().getVector()[1]);

        game.update_unitTest();

        assertEquals(-1,(int)game.getBall().getVector()[0]);
        assertEquals(0,(int)game.getBall().getVector()[1]);
    }

    @Test
    public void checkCollisionWithWall() throws Exception {
        Game game=new Game(0,0,200,200,10,new double[]{10,30},1,1,1,new Ball(100,6,0,-1),null);
        game.setPlaying(true);

        assertEquals(0,(int)game.getBall().getVector()[0]);
        assertEquals(-1,(int)game.getBall().getVector()[1]);

        game.update_unitTest();

        assertEquals(0,(int)game.getBall().getVector()[0]);
        assertEquals(-1,(int)game.getBall().getVector()[1]);

        game.update_unitTest();

        assertEquals(0,(int)game.getBall().getVector()[0]);
        assertEquals(1,(int)game.getBall().getVector()[1]);


        game.getBall().setPositionx(100);
        game.getBall().setPositiony(194);
        game.getBall().setVector(new double[]{0,1});

        assertEquals(0,(int)game.getBall().getVector()[0]);
        assertEquals(1,(int)game.getBall().getVector()[1]);

        game.update_unitTest();

        assertEquals(0,(int)game.getBall().getVector()[0]);
        assertEquals(1,(int)game.getBall().getVector()[1]);

        game.update_unitTest();

        assertEquals(0,(int)game.getBall().getVector()[0]);
        assertEquals(-1,(int)game.getBall().getVector()[1]);


        game.getBall().setPositionx(194);
        game.getBall().setPositiony(190);
        game.getBall().setVector(new double[]{1,0});

        assertEquals(true,game.getPlaying());

        game.update_unitTest();

        assertEquals(true,game.getPlaying());

        game.update_unitTest();

        assertEquals(false,game.getPlaying());

        game.getBall().setPositionx(6);
        game.getBall().setPositiony(190);
        game.getBall().setVector(new double[]{-1,0});
        game.setPlaying(true);

        assertEquals(true,game.getPlaying());

        game.update_unitTest();

        assertEquals(true,game.getPlaying());

        game.update_unitTest();

        assertEquals(false,game.getPlaying());

    }

    @Test
    public void checkCollisionWithPaddle() throws Exception {
        Game game=new Game(0,0,200,200,10,new double[]{10,30},1,1,1,new Ball(184,100,1,0),null);
        game.setPlaying(true);

        assertEquals(1,(int)game.getBall().getVector()[0]);
        assertEquals(0,(int)game.getBall().getVector()[1]);

        game.update_unitTest();

        assertEquals(1,(int)game.getBall().getVector()[0]);
        assertEquals(0,(int)game.getBall().getVector()[1]);

        game.update_unitTest();

        assertEquals(-1,(int)game.getBall().getVector()[0]);
        assertEquals(0,(int)game.getBall().getVector()[1]);

        game.getBall().setPositionx(16);
        game.getBall().setPositiony(100);
        game.getBall().setVector(new double[]{-1,0});

        assertEquals(-1,(int)game.getBall().getVector()[0]);
        assertEquals(0,(int)game.getBall().getVector()[1]);

        game.update_unitTest();

        assertEquals(-1,(int)game.getBall().getVector()[0]);
        assertEquals(0,(int)game.getBall().getVector()[1]);

        game.update_unitTest();

        assertEquals(1,(int)game.getBall().getVector()[0]);
        assertEquals(0,(int)game.getBall().getVector()[1]);
    }



}