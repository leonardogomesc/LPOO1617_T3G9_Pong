package com.example.up201503708.pong;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Random;


public class Game {
	private Ball ball;
	private Ball ballSim; //ball used for a simulation in order to calculate the position in which the AI should be
	private Player p1; //player 1
	private Player p2; //player 2
	private Obstacle o[]; //array containing the obstacles , null if there are no obstacles
	private double ballVelocity; //used to adjust the ball velocity
	private double paddleVelocity; //used to adjust the paddle velocity
	public double ballSize; // size of the ball in pixels
	public double paddleSize[]=new double[2]; // size of the paddle in pixels, paddleSize[0] for x and paddleSize[1] for y
	public static double min_screen_x; // used to define the pixel that corresponds to the map border
	public static double min_screen_y; // used to define the pixel that corresponds to the map border
	public static double max_screen_x; // used to define the pixel that corresponds to the map border
	public static double max_screen_y; // used to define the pixel that corresponds to the map border
	public double targetPosP1; // position where the player 1 wants to go
	public double targetPosP2; // position where the player 2 wants to go
	private int numberOfPlayers; // number of players
	private int finalPosition; // if 1 the ball will hit the left wall next, if 2 the ball will hit the right wall next. Its calculated with the simulation() function
	private double computerPaddleVelocity; //used to adjust the AI paddle velocity
	private double computerPaddleZone; //AI paddle divided into 7 sections, values can be -3(top of the paddle), -2, -1, 0(middle), 1, 2, 3(bottom of the paddle)
	private Context context;
	private GameSurfaceView gameSurfaceView;
	private FileInputStream fileInputStream;
	private InputStream inputStream;
	private String map; // map name
	private boolean useDefaultFile;
	
	private boolean playing; // true if the game is active, false otherwise

	/**
	 *
	 * @param min_x used to define the pixel that corresponds to the map border
	 * @param min_y used to define the pixel that corresponds to the map border
	 * @param max_x used to define the pixel that corresponds to the map border
	 * @param max_y used to define the pixel that corresponds to the map border
	 * @param numberOfPlayers number of players
	 * @param context
	 * @param gameSurfaceView
	 */
	public Game(int min_x,int min_y, int max_x,int max_y, int numberOfPlayers,Context context,GameSurfaceView gameSurfaceView){

		this.context=context;
		this.gameSurfaceView=gameSurfaceView;

		min_screen_x=min_x;
		min_screen_y=min_y;
		max_screen_x=max_x;
		max_screen_y=max_y;

		//calculates the ball size relative to the size of the screen
		ballSize=(max_screen_x-min_screen_x)*0.026;

		//calculates the paddle size relative to the size of the screen
		paddleSize[0]=(max_screen_x-min_screen_x)*0.0156;
		paddleSize[1]=(max_screen_y-min_screen_y)*0.174;

		readSettings();

		readMap();

		ballSim=null;
		
		// calculates the starting player positions (all coordinates are relative to the center of the object)
		if(numberOfPlayers==2) {
			p1=new Player(min_screen_x+(max_screen_x-min_screen_x)*0.078,(max_screen_y+min_screen_y)/2);
		}
		else if(numberOfPlayers==1){
			p1=new Player(min_screen_x+(max_screen_x-min_screen_x)*0.0156,(max_screen_y+min_screen_y)/2);
		}

		p2 = new Player(max_screen_x - (max_screen_x-min_screen_x)*0.078, (max_screen_y + min_screen_y) / 2);

		targetPosP1=(max_screen_y+min_screen_y)/2;
		targetPosP2=(max_screen_y+min_screen_y)/2;
		
		this.numberOfPlayers=numberOfPlayers;
		
		playing=false;
		finalPosition=-1; // when finalPosition equals -1 the simulation() function is called

		computerPaddleZone=0;
	}

	/**
	 * constructor used for unit testing
	 *
	 * @param min_x
	 * @param min_y
	 * @param max_x
	 * @param max_y
	 * @param ballSize
	 * @param paddleSize
	 * @param ballVelocity
	 * @param computerPaddleVelocity
	 * @param paddleVelocity
	 * @param ball
	 * @param obstacles
	 */
    public Game(int min_x,int min_y, int max_x,int max_y,double ballSize,double paddleSize[]
            ,double ballVelocity,double computerPaddleVelocity,double paddleVelocity,Ball ball,Obstacle obstacles[]){

        this.context=null;
        this.gameSurfaceView=null;

        min_screen_x=min_x;
        min_screen_y=min_y;
        max_screen_x=max_x;
        max_screen_y=max_y;


        this.ballSize=ballSize;

        this.paddleSize[0]=paddleSize[0];
        this.paddleSize[1]=paddleSize[1];

        this.ballVelocity=ballVelocity;
        this.computerPaddleVelocity=computerPaddleVelocity;
        this.paddleVelocity=paddleVelocity;

        this.ball=ball;

        ballSim=null;

        p1=new Player(min_screen_x+paddleSize[0]/2,(max_screen_y+min_screen_y)/2);

        p2 = new Player(max_screen_x - paddleSize[0]/2, (max_screen_y + min_screen_y) / 2);

        targetPosP1=(max_screen_y+min_screen_y)/2;
        targetPosP2=(max_screen_y+min_screen_y)/2;

        this.numberOfPlayers=2;

		o=obstacles;

        playing=false;
        finalPosition=-1; // when finalPosition equals -1 the simulation() function is called

        computerPaddleZone=0;
    }


	/**
	 * opens the settings file and calls other functions that read it
	 *
	 */
	private void readSettings(){
		boolean exists;
		File file= context.getFileStreamPath("settings");
		fileInputStream=null;
		inputStream=null;

		if(file==null || !file.exists()){
			exists=false;
		}
		else{
			exists=true;
		}

		if(exists){
			try {
				fileInputStream = context.openFileInput("settings");
			}
			catch (Exception e){
				e.printStackTrace();
			}
		}
		else{
			try {
				inputStream =context.getAssets().open("settings.txt");
			}
			catch (Exception e){
				e.printStackTrace();
			}
		}

		if(fileInputStream==null && inputStream!=null){
			useDefaultFile=true;
		}
		else if(fileInputStream!=null && inputStream==null){
			useDefaultFile=false;
		}
		else{
			useDefaultFile=true;
		}

		readMapName();
        readVariables();
	}

	/**
	 * opens the map file and calls other functions that read it
	 *
	 */
	private void readMap(){
		fileInputStream=null;
		inputStream=null;

			try {
				inputStream =context.getAssets().open("maps/"+map);
			}
			catch (Exception e){
				e.printStackTrace();
			}

        readBallInfo();
        readObstacles();
	}

	/**
	 * reads the map name on the settings file
	 *
	 */
	private void readMapName(){
		String message="";
		boolean reading;
		int character;

		if(useDefaultFile){
			try {
				reading=true;
				while (reading) {
					character = inputStream.read();
					if (((char)character)!='/'){
						message=message+(char)character;
					}else if(((char)character)=='/'){
						reading=false;
					}
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}

		}
		else if(!useDefaultFile){
			try {
				reading=true;
				while (reading) {
					character = fileInputStream.read();
					if (((char)character)!='/'){
						message=message+(char)character;
					}else if(((char)character)=='/'){
						reading=false;
					}
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		map=message;
	}

	/**
	 * reads and creates the obstacles from the map file
	 *
	 */
	private void readObstacles(){
		int numberOfObstacles;
		double x=0;
		double y=0;
		double size_x=0;
		double size_y=0;

		boolean reading;
		int character;
		String message="";

		try {
			reading = true;
			while (reading) {
				character = inputStream.read();
				if (((char) character) != '/') {
					message = message + (char) character;
				} else if (((char) character) == '/') {
					reading = false;
				}
			}

			numberOfObstacles = Integer.parseInt(message);


			if (numberOfObstacles == 0) {
				o = null;
			} else {
				o = new Obstacle[numberOfObstacles];

				for (int i = 0; i < o.length; i++) {

					for(int i2=0;i2<3;i2++) {
						message = "";
						reading = true;
						while (reading) {
							character = inputStream.read();
							if (((char) character) != ';') {
								message = message + (char) character;
							} else if (((char) character) == ';') {
								reading = false;
							}
						}

						if(i2==0) {
							x = Double.parseDouble(message);
						}
						else if(i2==1){
							y = Double.parseDouble(message);
						}
						else if(i2==2){
							size_x=Double.parseDouble(message);
						}
					}

					message = "";
					reading = true;
					while (reading) {
						character = inputStream.read();
						if (((char) character) != '/') {
							message = message + (char) character;
						} else if (((char) character) == '/') {
							reading = false;
						}
					}

					size_y=Double.parseDouble(message);

					o[i]=new Obstacle(min_screen_x+(max_screen_x-min_screen_x)*x,min_screen_y+(max_screen_y-min_screen_y)*y,(max_screen_x-min_screen_x)*size_x,(max_screen_y-min_screen_y)*size_y);
				}
			}
			}
		catch(Exception e){
				e.printStackTrace();
			}

			try{
				if(inputStream!=null){
					inputStream.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
	}

	/**
	 * reads ball position from the map file and creates the ball
	 */
	private void readBallInfo(){
		double x=0;
		double y=0;

		boolean reading;
		int character;
		String message="";

			try {
				reading=true;
				while (reading) {
					character = inputStream.read();
					if (((char)character)!=';'){
						message=message+(char)character;
					}else if(((char)character)==';'){
						reading=false;
					}
				}

				x=Double.parseDouble(message);
				message="";

				reading=true;
				while (reading) {
					character = inputStream.read();
					if (((char)character)!='/'){
						message=message+(char)character;
					}else if(((char)character)=='/'){
						reading=false;
					}
				}

				y=Double.parseDouble(message);
			}
			catch(Exception e){
				e.printStackTrace();
			}

		ball=new Ball(min_screen_x+(max_screen_x-min_screen_x)*x,min_screen_y+(max_screen_y-min_screen_y)*y,Math.cos(Math.toRadians(0)),Math.sin(Math.toRadians(0)));
	}

	/**
	 * reads the ballVelocity, paddleVelocity and computerPaddleVelocity from the settings file
	 *
	 */
	public void readVariables(){
		String message="";
		boolean reading;
		int character;

		if(useDefaultFile){
			try {
				reading=true;
				while (reading) {
					character = inputStream.read();
					if (((char)character)!='/'){
						message=message+(char)character;
					}else if(((char)character)=='/'){
						reading=false;
					}
				}

				ballVelocity=(max_screen_x-min_screen_x)*Double.parseDouble(message);
				message="";

				reading=true;
				while (reading) {
					character = inputStream.read();
					if (((char)character)!='/'){
						message=message+(char)character;
					}else if(((char)character)=='/'){
						reading=false;
					}
				}

				paddleVelocity=(max_screen_y-min_screen_y)*Double.parseDouble(message);
				message="";

				reading=true;
				while (reading) {
					character = inputStream.read();
					if (((char)character)!='/'){
						message=message+(char)character;
					}else if(((char)character)=='/'){
						reading=false;
					}
				}

				computerPaddleVelocity=(max_screen_y-min_screen_y)*Double.parseDouble(message);

			}
			catch(Exception e){
				e.printStackTrace();
			}

		}
		else if(!useDefaultFile){
			try {
				reading=true;
				while (reading) {
					character = fileInputStream.read();
					if (((char)character)!='/'){
						message=message+(char)character;
					}else if(((char)character)=='/'){
						reading=false;
					}
				}

				ballVelocity=(max_screen_x-min_screen_x)*Double.parseDouble(message);
				message="";

				reading=true;
				while (reading) {
					character = fileInputStream.read();
					if (((char)character)!='/'){
						message=message+(char)character;
					}else if(((char)character)=='/'){
						reading=false;
					}
				}

				paddleVelocity=(max_screen_y-min_screen_y)*Double.parseDouble(message);
				message="";

				reading=true;
				while (reading) {
					character = fileInputStream.read();
					if (((char)character)!='/'){
						message=message+(char)character;
					}else if(((char)character)=='/'){
						reading=false;
					}
				}

				computerPaddleVelocity=(max_screen_y-min_screen_y)*Double.parseDouble(message);

			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

		try {
			if (fileInputStream != null) {
				fileInputStream.close();
			}
		}
		catch(Exception e){
				e.printStackTrace();
			}

		try {
			if (inputStream != null) {
				inputStream.close();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * updates the game every frame
	 */
	public void update(){
	
		if(playing){
			collisionHandler();
			
			if(finalPosition==-1){
				simulation();
			}

			if(numberOfPlayers!=2 && finalPosition==1){
				aiPaddleMovement(p1);
			}
			else if(numberOfPlayers==2){
				paddleMovement(p1,targetPosP1);
			}

			paddleMovement(p2,targetPosP2);

			updateBallPos(ball);
			
		}
		
	}

	/**
	 * update used by unit tests
	 */
	public void update_unitTest(){

		if(playing){
			collisionHandler();

			paddleMovement(p1,targetPosP1);

			paddleMovement(p2,targetPosP2);

			updateBallPos(ball);

		}

	}

	/**
	 * updates player position
	 *
	 * @param p player to be updated
	 * @param targetPos position where the player wants to be
	 */
	public void paddleMovement(Player p, double targetPos){
		if(p.getPos()[1]>targetPos){
			if((p.getPos()[1]-targetPos)>(max_screen_y-min_screen_y)*0.0208) {
				p.setPos_y(p.getPos()[1] - paddleVelocity);
			}
		}
		else if(p.getPos()[1]<targetPos){
			if((targetPos-p.getPos()[1])>(max_screen_y-min_screen_y)*0.0208) {
				p.setPos_y(p.getPos()[1] + paddleVelocity);
			}
		}
	}

	/**
	 * updates the AI's position
	 *
	 * @param p AI paddle
	 */
	
	public void aiPaddleMovement(Player p){
		if(p.getPos()[1]+computerPaddleZone*paddleSize[1]/7< ballSim.getPosition()[1]){
			if(ballSim.getPosition()[1]-(p.getPos()[1]+computerPaddleZone*paddleSize[1]/7)>(max_screen_y-min_screen_y)*0.0104){
				p.setPos_y(p.getPos()[1]+computerPaddleVelocity);
			}
		}
		else if(p.getPos()[1]+computerPaddleZone*paddleSize[1]/7>ballSim.getPosition()[1]){
			if((p.getPos()[1]+computerPaddleZone*paddleSize[1]/7)-ballSim.getPosition()[1]>(max_screen_y-min_screen_y)*0.0104){
				p.setPos_y(p.getPos()[1]-computerPaddleVelocity);
			}
		}
	}

	/**
	 *
	 * @return ball object
	 */
	public Ball getBall(){
		return ball;
	}

	/**
	 *
	 * @return if true the game is active, if false it is not
	 */
	public boolean getPlaying(){
		return playing;
	}

	/**
	 *
	 * @param a sets playing
	 */
	public void setPlaying(boolean a){
		playing=a;
		
	}

	/**
	 * checks if the ball collided with the paddle, if it did it changes the ball´s direction, and sets finalPosition=-1
	 * so that the next final position of the ball is calculated
	 *
	 * @return true if the ball collided with the paddle of player 1,false otherwise
	 */
	public boolean player1CollisionHandler(){
		boolean collidedWithPaddle=false;

		if(ball.getPosition()[0]<=ballSize/2+p1.getPos()[0]+paddleSize[0]/2 &&
				ball.getPosition()[1]<= p1.getPos()[1]+paddleSize[1]/2 && 
				ball.getPosition()[1]> p1.getPos()[1]+paddleSize[1]/2-paddleSize[1]/7 &&
				ball.getVector()[0]<0 &&
				ball.getPosition()[0]>=p1.getPos()[0]-paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(Math.cos(Math.toRadians(60)));
			ball.setVector_y(Math.sin(Math.toRadians(60)));
			finalPosition=-1;
		}else if(ball.getPosition()[0]<=ballSize/2+p1.getPos()[0]+paddleSize[0]/2 &&
				ball.getPosition()[1]<=p1.getPos()[1]+paddleSize[1]/2-paddleSize[1]/7 && 
				ball.getPosition()[1]> p1.getPos()[1]+paddleSize[1]/2-2*paddleSize[1]/7 &&
				ball.getVector()[0]<0 &&
				ball.getPosition()[0]>=p1.getPos()[0]-paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(Math.cos(Math.toRadians(40)));
			ball.setVector_y(Math.sin(Math.toRadians(40)));
			finalPosition=-1;
		}else if(ball.getPosition()[0]<=ballSize/2+p1.getPos()[0]+paddleSize[0]/2 &&
				ball.getPosition()[1]<= p1.getPos()[1]+paddleSize[1]/2-2*paddleSize[1]/7 && 
				ball.getPosition()[1]>  p1.getPos()[1]+paddleSize[1]/2-3*paddleSize[1]/7 && 
				ball.getVector()[0]<0 &&
				ball.getPosition()[0]>=p1.getPos()[0]-paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(Math.cos(Math.toRadians(20)));
			ball.setVector_y(Math.sin(Math.toRadians(20)));
			finalPosition=-1;
		}else if(ball.getPosition()[0]<=ballSize/2+p1.getPos()[0]+paddleSize[0]/2 &&
				ball.getPosition()[1]<= p1.getPos()[1]+paddleSize[1]/2-3*paddleSize[1]/7 &&
				ball.getPosition()[1]>  p1.getPos()[1]+paddleSize[1]/2-4*paddleSize[1]/7 && 
				ball.getVector()[0]<0 &&
				ball.getPosition()[0]>=p1.getPos()[0]-paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(Math.cos(Math.toRadians(0)));
			ball.setVector_y(Math.sin(Math.toRadians(0)));
			finalPosition=-1;
		}else if(ball.getPosition()[0]<=ballSize/2+p1.getPos()[0]+paddleSize[0]/2 &&
				ball.getPosition()[1]<= p1.getPos()[1]+paddleSize[1]/2-4*paddleSize[1]/7 && 
				ball.getPosition()[1]>  p1.getPos()[1]+paddleSize[1]/2-5*paddleSize[1]/7 &&
				ball.getVector()[0]<0 &&
				ball.getPosition()[0]>=p1.getPos()[0]-paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(Math.cos(Math.toRadians(20)));
			ball.setVector_y(-Math.sin(Math.toRadians(20)));
			finalPosition=-1;
		}else if(ball.getPosition()[0]<=ballSize/2+p1.getPos()[0]+paddleSize[0]/2 && 
				ball.getPosition()[1]<= p1.getPos()[1]+paddleSize[1]/2-5*paddleSize[1]/7 &&
				ball.getPosition()[1]>  p1.getPos()[1]+paddleSize[1]/2-6*paddleSize[1]/7 && 
				ball.getVector()[0]<0 &&
				ball.getPosition()[0]>=p1.getPos()[0]-paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(Math.cos(Math.toRadians(40)));
			ball.setVector_y(-Math.sin(Math.toRadians(40)));
			finalPosition=-1;
		}else if(ball.getPosition()[0]<=ballSize/2+p1.getPos()[0]+paddleSize[0]/2 && 
				ball.getPosition()[1]<= p1.getPos()[1]+paddleSize[1]/2-6*paddleSize[1]/7 && 
				ball.getPosition()[1]>=  p1.getPos()[1]+paddleSize[1]/2-7*paddleSize[1]/7 &&
				ball.getVector()[0]<0 &&
				ball.getPosition()[0]>=p1.getPos()[0]-paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(Math.cos(Math.toRadians(60)));
			ball.setVector_y(-Math.sin(Math.toRadians(60)));
			finalPosition=-1;
		}
		
		return collidedWithPaddle;
	}

	/**
	 * checks if the ball collided with the paddle, if it did it changes the ball´s direction, and sets finalPosition=-1
	 * so that the next final position of the ball is calculated
	 *
	 * @return true if the ball collided with the paddle of player 2,false otherwise
	 */
	
	public boolean player2CollisionHandler(){
		
		boolean collidedWithPaddle=false;

		if(ball.getPosition()[0]>=p2.getPos()[0]-paddleSize[0]/2-ballSize/2 &&
				ball.getPosition()[1]<= p2.getPos()[1]+paddleSize[1]/2 &&
				ball.getPosition()[1]> p2.getPos()[1]+paddleSize[1]/2-paddleSize[1]/7 &&
				ball.getVector()[0]>0 && 
				ball.getPosition()[0]<=p2.getPos()[0]+paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(-Math.cos(Math.toRadians(60)));
			ball.setVector_y(Math.sin(Math.toRadians(60)));
			finalPosition=-1;
		}else if(ball.getPosition()[0]>=p2.getPos()[0]-paddleSize[0]/2-ballSize/2 && 
				ball.getPosition()[1]<=p2.getPos()[1]+paddleSize[1]/2-paddleSize[1]/7 && 
				ball.getPosition()[1]> p2.getPos()[1]+paddleSize[1]/2-2*paddleSize[1]/7 && 
				ball.getVector()[0]>0 &&
				ball.getPosition()[0]<=p2.getPos()[0]+paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(-Math.cos(Math.toRadians(40)));
			ball.setVector_y(Math.sin(Math.toRadians(40)));
			finalPosition=-1;
		}else if(ball.getPosition()[0]>=p2.getPos()[0]-paddleSize[0]/2-ballSize/2 && 
				ball.getPosition()[1]<= p2.getPos()[1]+paddleSize[1]/2-2*paddleSize[1]/7 &&
				ball.getPosition()[1]> p2.getPos()[1]+paddleSize[1]/2-3*paddleSize[1]/7 &&
				ball.getVector()[0]>0 && 
				ball.getPosition()[0]<=p2.getPos()[0]+paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(-Math.cos(Math.toRadians(20)));
			ball.setVector_y(Math.sin(Math.toRadians(20)));
			finalPosition=-1;
		}else if(ball.getPosition()[0]>=p2.getPos()[0]-paddleSize[0]/2-ballSize/2 && 
				ball.getPosition()[1]<= p2.getPos()[1]+paddleSize[1]/2-3*paddleSize[1]/7 && 
				ball.getPosition()[1]> p2.getPos()[1]+paddleSize[1]/2-4*paddleSize[1]/7 &&
				ball.getVector()[0]>0 && 
				ball.getPosition()[0]<=p2.getPos()[0]+paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(-Math.cos(Math.toRadians(0)));
			ball.setVector_y(Math.sin(Math.toRadians(0)));
			finalPosition=-1;
		}else if(ball.getPosition()[0]>=p2.getPos()[0]-paddleSize[0]/2-ballSize/2 &&
				ball.getPosition()[1]<= p2.getPos()[1]+paddleSize[1]/2-4*paddleSize[1]/7 && 
				ball.getPosition()[1]> p2.getPos()[1]+paddleSize[1]/2-5*paddleSize[1]/7 &&
				ball.getVector()[0]>0 &&
				ball.getPosition()[0]<=p2.getPos()[0]+paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(-Math.cos(Math.toRadians(20)));
			ball.setVector_y(-Math.sin(Math.toRadians(20)));
			finalPosition=-1;
		}else if(ball.getPosition()[0]>=p2.getPos()[0]-paddleSize[0]/2-ballSize/2 &&
				ball.getPosition()[1]<= p2.getPos()[1]+paddleSize[1]/2-5*paddleSize[1]/7 && 
				ball.getPosition()[1]> p2.getPos()[1]+paddleSize[1]/2-6*paddleSize[1]/7 &&
				ball.getVector()[0]>0 && 
				ball.getPosition()[0]<=p2.getPos()[0]+paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(-Math.cos(Math.toRadians(40)));
			ball.setVector_y(-Math.sin(Math.toRadians(40)));
			finalPosition=-1;
		}else if(ball.getPosition()[0]>=p2.getPos()[0]-paddleSize[0]/2-ballSize/2 && 
				ball.getPosition()[1]<= p2.getPos()[1]+paddleSize[1]/2-6*paddleSize[1]/7 &&
				ball.getPosition()[1]>= p2.getPos()[1]+paddleSize[1]/2-7*paddleSize[1]/7 && 
				ball.getVector()[0]>0 && 
				ball.getPosition()[0]<=p2.getPos()[0]+paddleSize[0]/2){

			collidedWithPaddle=true;
			ball.setVector_x(-Math.cos(Math.toRadians(60)));
			ball.setVector_y(-Math.sin(Math.toRadians(60)));
			finalPosition=-1;
		}

			return collidedWithPaddle;		
	}

	/**
	 * checks if the ball collided with the walls, if it did it changes the ball´s direction, if it collides with the right or
	 * left wall it means that the game ended and the player score is incremented
	 */
	public void wallCollisionHandler(){
		if(ball.getPosition()[0]<=min_screen_x+ballSize/2 && ball.getVector()[0]<0){
			playing=false;
            if(gameSurfaceView!=null) {
                gameSurfaceView.score[1]++;
            }
		}
		else if(ball.getPosition()[1]<=min_screen_y+ballSize/2 && ball.getVector()[1]<0){
			ball.setVector_y(-ball.getVector()[1]);
		}
		else if(ball.getPosition()[0]>=max_screen_x-ballSize/2 && ball.getVector()[0]>0){
			playing=false;
            if(gameSurfaceView!=null) {
                gameSurfaceView.score[0]++;
            }
		}
		else if(ball.getPosition()[1]>=max_screen_y-ballSize/2 && ball.getVector()[1]>0){
			ball.setVector_y(-ball.getVector()[1]);

		}
	}

	/**
	 * checks if ball collided with obstacles, if it did the ball direction is changed
	 *
	 * @param ball object to be used
	 */
	
	public void obstacleCollisionHandler(Ball ball){
		
			for(int i=0;i< o.length;i++){

				if(ball.getVector()[1]>0 &&
						ball.getPosition()[1]<o[i].getK()[0]*ball.getPosition()[0]+o[i].getB()[0] &&
						ball.getPosition()[1]<o[i].getK()[1]*ball.getPosition()[0]+o[i].getB()[1] &&
						ball.getPosition()[1]>o[i].getPos()[1]-o[i].getSize()[1]/2-ballSize/2 &&
						ball.getPosition()[0]<o[i].getPos()[0]+o[i].getSize()[0]/2 && 
						ball.getPosition()[0]>o[i].getPos()[0]-o[i].getSize()[0]/2){
					ball.setVector_y(-ball.getVector()[1]);
				}
				else if(ball.getVector()[0]<0 && 
						ball.getPosition()[1]<o[i].getK()[0]*ball.getPosition()[0]+o[i].getB()[0] &&
						ball.getPosition()[1]>o[i].getK()[1]*ball.getPosition()[0]+o[i].getB()[1] && 
						ball.getPosition()[0]<o[i].getPos()[0]+o[i].getSize()[0]/2+ballSize/2 && 
						ball.getPosition()[1]<o[i].getPos()[1]+o[i].getSize()[1]/2 && 
						ball.getPosition()[1]>o[i].getPos()[1]-o[i].getSize()[1]/2){
					ball.setVector_x(-ball.getVector()[0]);
				}
				else if(ball.getVector()[1]<0 && 
						ball.getPosition()[1]>o[i].getK()[0]*ball.getPosition()[0]+o[i].getB()[0] && 
						ball.getPosition()[1]>o[i].getK()[1]*ball.getPosition()[0]+o[i].getB()[1] && 
						ball.getPosition()[1]<o[i].getPos()[1]+o[i].getSize()[1]/2+ballSize/2 &&
						ball.getPosition()[0]<o[i].getPos()[0]+o[i].getSize()[0]/2 && 
						ball.getPosition()[0]>o[i].getPos()[0]-o[i].getSize()[0]/2){
					ball.setVector_y(-ball.getVector()[1]);
				}
				else if(ball.getVector()[0]>0 &&
						ball.getPosition()[1]>o[i].getK()[0]*ball.getPosition()[0]+o[i].getB()[0] && 
						ball.getPosition()[1]<o[i].getK()[1]*ball.getPosition()[0]+o[i].getB()[1] && 
						ball.getPosition()[0]>o[i].getPos()[0]-o[i].getSize()[0]/2-ballSize/2 && 
						ball.getPosition()[1]<o[i].getPos()[1]+o[i].getSize()[1]/2 &&
						ball.getPosition()[1]>o[i].getPos()[1]-o[i].getSize()[1]/2){
					ball.setVector_x(-ball.getVector()[0]);
				}
				else if(Math.sqrt((Math.pow(((o[i].getPos()[0]-o[i].getSize()[0]/2)-ball.getPosition()[0]),2)+Math.pow(((o[i].getPos()[1]-o[i].getSize()[1]/2)-ball.getPosition()[1]),2)))<= ballSize/2 && !(ball.getVector()[0]<0 && ball.getVector()[1]<0)){
					ball.setVector_x(-Math.cos(Math.toRadians(45)));
					ball.setVector_y(-Math.sin(Math.toRadians(45)));

				}
				else if(Math.sqrt((Math.pow(((o[i].getPos()[0]+o[i].getSize()[0]/2)-ball.getPosition()[0]),2)+Math.pow(((o[i].getPos()[1]-o[i].getSize()[1]/2)-ball.getPosition()[1]),2)))<= ballSize/2 && !(ball.getVector()[0]>0 && ball.getVector()[1]<0)){
					ball.setVector_x(Math.cos(Math.toRadians(45)));
					ball.setVector_y(-Math.sin(Math.toRadians(45)));
				}
				else if(Math.sqrt((Math.pow(((o[i].getPos()[0]+o[i].getSize()[0]/2)-ball.getPosition()[0]),2)+Math.pow(((o[i].getPos()[1]+o[i].getSize()[1]/2)-ball.getPosition()[1]),2)))<= ballSize/2 && !(ball.getVector()[0]>0 && ball.getVector()[1]>0)){
					ball.setVector_x(Math.cos(Math.toRadians(45)));
					ball.setVector_y(Math.sin(Math.toRadians(45)));
				}
				else if(Math.sqrt((Math.pow(((o[i].getPos()[0]-o[i].getSize()[0]/2)-ball.getPosition()[0]),2)+Math.pow(((o[i].getPos()[1]+o[i].getSize()[1]/2)-ball.getPosition()[1]),2)))<= ballSize/2 && !(ball.getVector()[0]<0 && ball.getVector()[1]>0)){
					ball.setVector_x(-Math.cos(Math.toRadians(45)));
					ball.setVector_y(Math.sin(Math.toRadians(45)));
				}

			}
	}

	/**
	 * calls the collision functions, in order to check if the game is finished and to change the ball's direction
	 *
	 */
	public void collisionHandler(){

	boolean collidedWithPaddle=false;
	
	collidedWithPaddle=player1CollisionHandler();
	
	collidedWithPaddle=player2CollisionHandler();
	
		if(!collidedWithPaddle){

			wallCollisionHandler();
			
			if(o!=null){
				obstacleCollisionHandler(ball);
		 }
	   }
	}

	/**
	 *
	 * @return player 1
	 */
	public Player getP1(){
		return p1;
	}

	/**
	 *
	 * @return player 2
	 */
	public Player getP2(){
		return p2;
	}


	/**
	 *
	 * @return obstacle array
	 */
	public Obstacle[] getObstacles(){
		return o;
	}


	/**
	 * makes a simulation of the current game to calculate the position where the AI paddle needs to be
	 * to hit the ball
	 */
	public void simulation(){
		ballSim=new Ball(ball.getPosition()[0],ball.getPosition()[1],ball.getVector()[0],ball.getVector()[1]);
		Random r=new Random();
		
		int counter=0;
	
		while(finalPosition==-1){
			// if counter >= 30000 it is assumed that the game is in an infinite loop, so the ball direction is
			//changed to end the loop
			if(counter<30000){
			updateSimulation();
			}
			else{
				ball.setVector_x(Math.cos(Math.acos(ball.getVector()[0])+(2*Math.PI/360)));
				ball.setVector_y(Math.sin(Math.asin(ball.getVector()[1])+(2*Math.PI/360)));
				
				ballSim=new Ball(ball.getPosition()[0],ball.getPosition()[1],ball.getVector()[0],ball.getVector()[1]);
				counter=0;
			}
			counter=counter+1;
		}

	 computerPaddleZone=r.nextInt(7)-3;
	 	
	}

	/**
	 * calls the functions that update the simulation
	 */
	private void updateSimulation() {
		simCollisionHandler();
		if(finalPosition==-1){
			updateBallPos(ballSim);
			}
	}

	/**
	 * Checks if the ball reached the left or the right side of the screen in which case it updates finalPosition,
	 * and the simulation is ended. It also checks if the ball collided with the top or bottom wall an if it did it
	 * changes the ball's direction
	 */
	private void simWallCollisionHandler(){
		if(ballSim.getPosition()[0]<=p1.getPos()[0]+paddleSize[0]/2+ballSize/2 && ballSim.getVector()[0]<0){
			finalPosition=1;
		}
		else if(ballSim.getPosition()[1]<=min_screen_y+ballSize/2 && ballSim.getVector()[1]<0){
			ballSim.setVector_y(-ballSim.getVector()[1]);
		}
		else if(ballSim.getPosition()[0]>=p2.getPos()[0]-paddleSize[0]/2-ballSize/2 && ballSim.getVector()[0]>0){
			finalPosition=2;
		}
		else if(ballSim.getPosition()[1]>=max_screen_y-ballSize/2 && ballSim.getVector()[1]>0){
			ballSim.setVector_y(-ballSim.getVector()[1]);

		}
		
	}

	/**
	 * updates the ball position
	 *
	 * @param ball ball to be updated
	 */
	
	private void updateBallPos(Ball ball){
		
		ball.setPositionx(ball.getPosition()[0]+ballVelocity*ball.getVector()[0]);
		ball.setPositiony(ball.getPosition()[1]+ballVelocity*ball.getVector()[1]);
	}

	/**
	 *
	 * calls the functions that handle collisions
	 */
	private void simCollisionHandler() {
		
		simWallCollisionHandler();
		
		if(o!=null){
			obstacleCollisionHandler(ballSim);
		}
	}	
}
