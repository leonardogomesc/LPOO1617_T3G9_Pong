package com.example.up201503708.pong;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;


public class GameSurfaceView extends SurfaceView implements SurfaceHolder.Callback{

    private LoopThread loopThread; // Thread that calls the update and draw method and limits the frame-rate
    public Game game;
    private Context context;
    public boolean startedGame; // true if the game started , false otherwise
    private int width; // screen width
    private int height; // screen height
    private int number_of_players;
    public int score[]; // current score

    /**
     * initializes the game object
     *
     * @param context
     * @param number_of_players 1 or 2
     * @param score
     */
    public GameSurfaceView(Context context, int number_of_players, int[] score){
        super(context);
        this.context=context;

        getHolder().addCallback(this);
        setFocusable(true);

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        width = size.x;
        height = size.y;
        startedGame=false;

        this.number_of_players=number_of_players;
        this.score=score;

       game=new Game(0,0,width,height,number_of_players,context,this);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height){


    }

    /**
     * starts the thread that calls the update and draw method and limits the frame-rate
     * @param holder
     */
    @Override
    public void surfaceCreated(SurfaceHolder holder){
        loopThread= new LoopThread(getHolder(),this);

        loopThread.setRunning(true);
        loopThread.start();
    }

    /**
     * calls the fuction that makes the thread exit the while loop and finish
     * @param holder
     */
    @Override
    public void surfaceDestroyed(SurfaceHolder holder){
      killThread();
    }

    /**
     * makes the thread exit the while loop and finish
     */
    public void killThread(){
        boolean retry=true;
        while(retry){
            retry=false;
            try {
                loopThread.setRunning(false);
                loopThread.join();
            }catch (Exception e){
                e.getStackTrace();
                retry=true;
            }
        }
    }

    /**
     * starts the lossScreen activity when the game finishes, and sends the number of players and the score, that is then
     * showed on the screen
     *
     */
    public void lossScreen(){
        Intent intent =new Intent(context,LossScreen.class);
        intent.putExtra("Number of Players",number_of_players);
        intent.putExtra("Score",score);
        context.startActivity(intent);
    }


    /**
     * handles touch events and starts the game
     *
     * @param event
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int pointer_1;
        int pointer_2;

        if(game.getPlaying()==false && startedGame==false){
            game.setPlaying(true);
            startedGame=true;
        }

        if(number_of_players==2) {
            if (event.getPointerCount() == 2) {
                pointer_1 = event.findPointerIndex(event.getPointerId(0));
                pointer_2 = event.findPointerIndex(event.getPointerId(1));

                if (event.getX(pointer_1) >= width / 2) {
                    game.targetPosP2 = (int) event.getY(pointer_1);
                } else {
                    game.targetPosP1 = (int) event.getY(pointer_1);
                }

                if (event.getX(pointer_2) >= width / 2) {
                    game.targetPosP2 = (int) event.getY(pointer_2);
                } else {
                    game.targetPosP1 = (int) event.getY(pointer_2);
                }
            } else if (event.getPointerCount() == 1) {
                pointer_1 = event.findPointerIndex(event.getPointerId(0));

                if (event.getX(pointer_1) >= width / 2) {
                    game.targetPosP2 = (int) event.getY(pointer_1);
                } else {
                    game.targetPosP1 = (int) event.getY(pointer_1);
                }
            }
        }
        else if(number_of_players==1) {
            game.targetPosP2 = (int) event.getY();
        }
        return true;
    }

    /**
     * calls the update function
     */
    public void update(){
        game.update();
    }

    /**
     * draws the game objects on the screen
     *
     * @param canvas
     */
    @Override
    public void draw(Canvas canvas){
        super.draw(canvas);
        canvas.drawColor(Color.rgb(255,255,255));

        Paint paint=new Paint();
        paint.setColor(Color.BLUE);


        Paint paint2=new Paint();
        paint2.setColor(Color.rgb(255,0,0));

        Paint paint3=new Paint();
        paint3.setColor(Color.rgb(80,80,80));


        canvas.drawCircle((float)game.getBall().getPosition()[0],(float)game.getBall().getPosition()[1],(float)game.ballSize/2,paint2);

        canvas.drawRect(new Rect((int)(game.getP1().getPos()[0]-game.paddleSize[0]/2),
                (int)(game.getP1().getPos()[1]-game.paddleSize[1]/2),
                (int)(game.getP1().getPos()[0]+game.paddleSize[0]/2),
                (int)(game.getP1().getPos()[1]+game.paddleSize[1]/2)),paint3);

        canvas.drawRect(new Rect((int)(game.getP2().getPos()[0]-game.paddleSize[0]/2),
                (int)(game.getP2().getPos()[1]-game.paddleSize[1]/2),
                (int)(game.getP2().getPos()[0]+game.paddleSize[0]/2),
                (int)(game.getP2().getPos()[1]+game.paddleSize[1]/2)),paint3);

        if(game.getObstacles()!=null) {
            for (int i = 0; i < game.getObstacles().length; i++) {

                canvas.drawRect(new Rect((int) (game.getObstacles()[i].getPos()[0] - game.getObstacles()[i].getSize()[0] / 2),
                        (int) (game.getObstacles()[i].getPos()[1] - game.getObstacles()[i].getSize()[1] / 2),
                        (int) (game.getObstacles()[i].getPos()[0] + game.getObstacles()[i].getSize()[0] / 2),
                        (int) (game.getObstacles()[i].getPos()[1] + game.getObstacles()[i].getSize()[1] / 2)), paint);
            }
        }
    }
}
